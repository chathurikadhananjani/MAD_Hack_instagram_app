package com.c2c20.madhack_instagram;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView storiesBar;
    private RecyclerView recyclerView;
    private ArrayList<Instagram> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        arrayList = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerView);
        arrayList.add(new Instagram(R.drawable.a,R.drawable.c,"Cambridge ","message"));
        arrayList.add(new Instagram(R.drawable.b,R.drawable.b,"Marry quora","message"));
        arrayList.add(new Instagram(R.drawable.h,R.drawable.post,"Jeny Wotson","message"));
        arrayList.add(new Instagram(R.drawable.c,R.drawable.h,"Sheril Shaden","message"));
        arrayList.add(new Instagram(R.drawable.f,R.drawable.e,"clark osiko","message"));

        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(arrayList);

        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    private void init(){
        storiesBar = findViewById(R.id.storiesBar);

        List<Story> stories = new ArrayList<>();
        stories.add(new Story(false));
        stories.add(new Story(false));
        stories.add(new Story(true));
        stories.add(new Story(true));
        stories.add(new Story(false));
        stories.add(new Story(true));
        stories.add(new Story(false));
        stories.add(new Story(true));

        StoriesAdapter adapter=new StoriesAdapter(stories, this);
        storiesBar.setAdapter(adapter);
        storiesBar.setLayoutManager(new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false));

        //settings the space between story items
        storiesBar.addItemDecoration(new StoriesDecoration(10));

    }

}