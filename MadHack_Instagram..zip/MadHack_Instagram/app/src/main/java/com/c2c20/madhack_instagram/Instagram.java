package com.c2c20.madhack_instagram;

public class Instagram {
    private int profileIcon;
    private int PostImage;
    private String title;
    private String message;

    public Instagram(int profileIcon, int postImage, String title, String message) {
        this.profileIcon = profileIcon;
        PostImage = postImage;
        this.title = title;
        this.message = message;
    }
    public int getProfileIcon() {
        return profileIcon;
    }
    public void setProfileIcon(int profileIcon) {
        this.profileIcon = profileIcon;
    }
    public int getPostImage() {
        return PostImage;
    }
    public void setPostImage(int postImage) {
        PostImage = postImage;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}
